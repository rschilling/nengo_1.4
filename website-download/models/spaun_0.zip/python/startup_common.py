"""A series of Python commands to execute when starting up Nengo."""

import ca.nengo
from ca.nengo.math.impl import *
import sys
sys.path.append('.')
sys.path.append('python')
from numeric import *
