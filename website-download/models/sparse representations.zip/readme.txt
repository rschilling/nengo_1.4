The scripts included here:

LCA2.py   (2.4 KB) - added by sshapero 6 weeks ago. Code for sparse representation of 8x8 inputs
LCAbig.py   (2.8 KB) - added by sshapero 6 weeks ago. Network for sparse representation of a 24x24 input.
LCAsal.py   (3.8 KB) - added by sshapero 6 weeks ago. Network for sparse representation of a 24x24 input. Computes a saliency map. Needs some tweaking.
LCAsal_UDP.py   (6.3 KB) - added by sshapero 6 weeks ago. NEF Network that takes UDP inputs, finds sparse representation, and attemtps to calculate saliency map. Needs serious tweaking. Takes a long time to load!
LCAbig2_UDP.py   (5.4 KB) - added by sshapero 6 weeks ago. NEF Network that takes 48x48 UDP inputs from jAER, subsamples it to a 24x24, finds sparse representation. Includes code for handling UDP.