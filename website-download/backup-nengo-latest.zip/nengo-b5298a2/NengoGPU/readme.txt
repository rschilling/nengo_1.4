NengoGPU is a shared library written in C and nVidia's CUDA API that permits using nVidia GPU's
for running simulations in Nengo. 

For detailed instructions on using a GPU with Nengo, see http://nengo.ca/docs/html/advanced/gpu.html.

Instructions are currently only available for Linux. Windows instructions are coming soon.
