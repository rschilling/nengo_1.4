"""A series of Python commands to execute when starting up
the graphical front-end to Nengo."""

execfile('python/startup_common.py')
import toolbar
