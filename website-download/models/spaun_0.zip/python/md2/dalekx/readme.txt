================================================================
 DALEKX.MD2 (mark one travel machine)                      v1.40
 Improved Sounds, skin, vwep, animation, and model. 
 An almost total rebuild
 by J. G. Watt                                      26 July 1998
 Last updated					17 december 1998
................................................................

================================================================
Title                   : Quake2 Dalek Player Model
Author                  : J.G.Watt (2 aditional skins by zaxxon
			  <ZaXXoN@mars-command.demon.co.uk>)

Homepage                : http://www.kinetic-arts.demon.co.uk

Email Address           : jim@kinetic-arts.demon.co.uk



Build Time              : 6 Days + 5 months of tweeking.
================================================================

DESCRIPTION

   This is a quake2 player model that allows you to play Quake2 
   as a DALEK. The file also includes 12 dalek skins. See also
   PREVIEW.JPG


INSTALLATION

   Copy the directory called DALEKX and its content to your 
   quake2\baseq2\players\
   directory.

TO USE

   Run quake2 go to Multiplay / PlayerSetup / Model and select
   DALEK. You can then choose a skin
   DALEKS also works well with some of the BOT programs like
   Eraser Bot by Ryan Feltrin (aka Ridah)
   Happy Exterminating.

WHAT'S NEW

   I've extensively updated dalekx since the last version.
   The model now has 52 fewer polygons in it.
   The skins are now nice efficiant 256x256 bitmaps.
   I added grenn CTF skins and a nice BRIT skin 
   (and a very ugly hippy skin).
   I've finished off all the animations.
   I've redone the viewable weapons. 

TO DO

   Can't think of anything right now.
   
ABOUT

   This is not only my first ever quake2 model but it's also my
   first ever 3DstudioMAX model. I picked a dalek because I didn't
   know how difficult it would be to create and animate a quake2 
   model so a Dalek would be a simple first project. It turned
   out to be quite easy so I'm going to attempt something a little
   more ambitious next (something with arms and legs).

   After writing the above I created MARTIAN for q2. See it on my 
   web page. 

DISCLAIMER

   I will not take responsibility for anything bad. Use at you 
   own risk bla de bla.

   You may freely distribute this archive, as long as it remains
   intact. If you want to add a skin then go for it but send me 
   a copy. You may not use these files for commercial purposes 
   without my permission (and probably that of the BBC and ID). 
   If you do so you will be EXTERMINATED. 

Additional Credits to   : id Software, the BBC.

Thanks to            : 	Ewan and Marcus for playtesting :-)

			Charles Caffrey author of 'Daleky.wad' 
			(for Doom2) for aditional .wav files

			Christopher Haynes for aditional .wav files


If you use the model then please email me your thoughts.
Terry Nation 4 ever.