import basalganglia
import nps
from nps import *
