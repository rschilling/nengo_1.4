Contact details:

Ashley Liddiard (University of Cape Town)
mobile: +27 (0) 79 571 0002
email: ashley.liddiard@gmail.com

With the assistance of T. Stewart (PhD) 

lamprey05_turnRight_showWeights: final workings of the simulation, details of parameters in commented code
lamprey01: first operational simulation


