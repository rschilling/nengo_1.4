package ca.nengo.model;

public interface StepListener {
	
	public void stepStarted(float time);
	
}
