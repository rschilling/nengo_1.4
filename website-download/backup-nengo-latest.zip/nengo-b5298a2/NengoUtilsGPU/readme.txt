NengoUtilsGPU is a shared library written in C and nVidia's CUDA API that permits using nVidia GPU's
for creating models in Nengo. It also requires CULA, a 3rd party GPU library of linear algebra routines.

For detailed instructions on using a GPU with Nengo, see http://nengo.ca/docs/html/advanced/gpu.html.

Instructions are currently only available for Linux. Windows instructions are coming soon.
