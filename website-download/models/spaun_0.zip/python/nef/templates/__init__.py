import integrator
import basalganglia
import basalganglia_rule
import linear_system
import binding
import networkarray
import gate
import learned_termination
import thalamus

templates=[
    networkarray,
    integrator,
    linear_system,
    binding,
    basalganglia,
    basalganglia_rule,
    thalamus,
    gate,
    learned_termination,
    ]
