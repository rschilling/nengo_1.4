##### INIT PATH #####
import sys
sys.path.append("spaun/")

from run_spaun import run
run(OS = "LIN", root_path = "spaun/", multi_thread = False)

sys.exit();
